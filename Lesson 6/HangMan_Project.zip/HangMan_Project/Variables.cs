﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman
{
    public class Degiskenler
    {
        public static string category = "Science", time = "Unlimited", hints = "Yes", difficulty= "Normal";

    }
}
